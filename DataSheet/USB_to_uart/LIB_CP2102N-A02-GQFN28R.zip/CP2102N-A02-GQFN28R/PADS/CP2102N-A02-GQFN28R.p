*PADS-LIBRARY-PART-TYPES-V9*

CP2102N-A02-GQFN28R QFN50P500X500X80-29N-D I ANA 9 1 0 0 0
TIMESTAMP 2025.08.31.10.32.37
"Manufacturer_Name" Silicon Labs
"Manufacturer_Part_Number" CP2102N-A02-GQFN28R
"Mouser Part Number" 634-CP2102NA02QFN28R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Silicon-Labs/CP2102N-A02-GQFN28R?qs=u16ybLDytRag4qKvSH3fTw%3D%3D
"Arrow Part Number" CP2102N-A02-GQFN28R
"Arrow Price/Stock" https://www.arrow.com/en/products/cp2102n-a02-gqfn28r/silicon-labs?utm_currency=USD&region=nac
"Description" USB Interface IC USB to UART bridge - QFN28
"Datasheet Link" https://www.silabs.com/documents/public/data-sheets/cp2102n-datasheet.pdf
"Geometry.Height" 0.8mm
GATE 1 29 0
CP2102N-A02-GQFN28R
1 0 U DCD
2 0 U RI_/_CLK
3 0 U GND_1
4 0 U D+
5 0 U D-
6 0 U VDD
7 0 U VREGIN
8 0 U VBUS
9 0 U RSTB
10 0 U NC
11 0 U SUSPENDB
12 0 U SUSPEND
13 0 U CHREN
14 0 U CHR1
21 0 U GPIO.5
20 0 U GPIO.6
19 0 U GPIO.0_/_TXT
18 0 U GPIO.1_/_RXT
17 0 U GPIO.2_/_RS485
16 0 U GPIO.3_/_WAKEUP
15 0 U CHR0
29 0 U GND_2
28 0 U DTR
27 0 U DSR
26 0 U TXD
25 0 U RXD
24 0 U RTS
23 0 U CTS
22 0 U GPIO.4

*END*
*REMARK* SamacSys ECAD Model
1916796/396967/2.50/29/3/Integrated Circuit
